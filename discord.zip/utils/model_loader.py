import os
import logging
import threading
import time
from typing import Optional, List, Dict, Any, Generator, Union
import config
import torch

logger = logging.getLogger("ModelLoader")

class ModelLoader:
    _instance = None
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = ModelLoader()
        return cls._instance
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.is_ready = False
        self.is_loading = False
        self.lock = threading.Lock()
        self.gpu_monitor = None
        
        # 嘗試導入 GPU 監控
        try:
            from utils.gpu_monitor import GPUMonitor
            self.gpu_monitor = GPUMonitor.get_instance()
        except ImportError:
            logger.warning("無法導入 GPUMonitor")
    
    def load_model(self):
        """載入模型"""
        with self.lock:
            if self.is_ready:
                logger.info("模型已經載入")
                return
            
            if self.is_loading:
                logger.info("模型正在載入中")
                return
            
            self.is_loading = True
        
        try:
            logger.info(f"開始載入模型: {config.LOCAL_MODEL_NAME}")
            start_time = time.time()
            
            # 載入必要的庫
            from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
            
            # 記錄 GPU 記憶體狀態
            if torch.cuda.is_available():
                gpu_info = {}
                for i in range(torch.cuda.device_count()):
                    free_memory, total_memory = torch.cuda.mem_get_info(i)
                    free_memory = free_memory / (1024**3)  # 轉換為 GB
                    total_memory = total_memory / (1024**3)  # 轉換為 GB
                    reserved = torch.cuda.memory_reserved(i) / (1024**3)  # 轉換為 GB
                    allocated = torch.cuda.memory_allocated(i) / (1024**3)  # 轉換為 GB
                    gpu_info[i] = {
                        "total": round(total_memory, 2),
                        "reserved": round(reserved, 2),
                        "allocated": round(allocated, 2),
                        "free": round(free_memory, 2)
                    }
                logger.info(f"GPU 記憶體狀態: {gpu_info}")
            
            # 設置設備
            device = config.LOCAL_MODEL_DEVICE
            logger.info(f"使用設備: {device}")
            
            # 設置數據類型
            dtype_map = {
                "float16": torch.float16,
                "bfloat16": torch.bfloat16,
                "float32": torch.float32,
                "auto": "auto"
            }
            dtype = dtype_map.get(config.LOCAL_MODEL_DTYPE.lower(), "auto")
            logger.info(f"使用數據類型: {dtype}")
            
            # 設置量化配置
            quantization_config = None
            if config.LOCAL_MODEL_QUANTIZATION.lower() != "none":
                if config.LOCAL_MODEL_QUANTIZATION.lower() == "4bit":
                    quantization_config = BitsAndBytesConfig(
                        load_in_4bit=True,
                        bnb_4bit_compute_dtype=dtype if dtype != "auto" else torch.float16
                    )
                    logger.info("使用 4-bit 量化")
                elif config.LOCAL_MODEL_QUANTIZATION.lower() == "8bit":
                    quantization_config = BitsAndBytesConfig(
                        load_in_8bit=True
                    )
                    logger.info("使用 8-bit 量化")
                elif config.LOCAL_MODEL_QUANTIZATION.lower() == "auto":
                    # 自動選擇量化方式
                    model_size_gb = self._estimate_model_size()
                    available_memory = self._get_available_gpu_memory()
                    
                    if available_memory is not None and model_size_gb is not None:
                        logger.info(f"估計模型大小: {model_size_gb:.2f} GB, 可用 GPU 記憶體: {available_memory:.2f} GB")
                        
                        # 如果可用記憶體不足，使用量化
                        if model_size_gb > available_memory * 0.7:  # 留出 30% 緩衝
                            quantization_config = BitsAndBytesConfig(
                                load_in_4bit=True,
                                bnb_4bit_compute_dtype=dtype if dtype != "auto" else torch.float16
                            )
                            logger.info("自動選擇使用 4-bit 量化")
            
            # 設置 Hugging Face 令牌
            hf_token = config.HUGGINGFACE_TOKEN
            if hf_token:
                logger.info("使用 Hugging Face 令牌進行模型訪問")
            
            # 設置模型載入參數
            model_kwargs = {
                "pretrained_model_name_or_path": config.LOCAL_MODEL_NAME,
                "cache_dir": config.LOCAL_MODEL_CACHE_DIR,
                "torch_dtype": dtype if dtype != "auto" else "auto",
                "device_map": device if device != "cpu" else None,
                "quantization_config": quantization_config
            }
            
            # 如果有 Hugging Face 令牌，添加到參數中
            if hf_token:
                model_kwargs["token"] = hf_token
            
            # 如果啟用了 Flash Attention
            if config.LOCAL_MODEL_USE_FLASH_ATTN and device != "cpu":
                try:
                    model_kwargs["attn_implementation"] = "flash_attention_2"
                    logger.info("啟用 Flash Attention 2")
                except Exception as e:
                    logger.warning(f"無法啟用 Flash Attention: {e}")
            
            # 載入分詞器
            tokenizer_kwargs = {
                "pretrained_model_name_or_path": config.LOCAL_MODEL_NAME,
                "cache_dir": config.LOCAL_MODEL_CACHE_DIR
            }
            
            # 如果有 Hugging Face 令牌，添加到分詞器參數中
            if hf_token:
                tokenizer_kwargs["token"] = hf_token
            
            self.tokenizer = AutoTokenizer.from_pretrained(**tokenizer_kwargs)
            
            # 載入模型
            self.model = AutoModelForCausalLM.from_pretrained(**model_kwargs)
            
            # 設置模型為評估模式
            self.model.eval()
            
            # 記錄載入時間
            load_time = time.time() - start_time
            logger.info(f"模型載入完成，耗時: {load_time:.2f} 秒")
            
            self.is_ready = True
        except Exception as e:
            logger.error(f"載入模型時發生錯誤：{e}")
            raise
        finally:
            self.is_loading = False
    
    def generate(self, prompt: str, system_prompt: str = None, max_new_tokens: int = 512, 
                 temperature: float = 0.7, top_p: float = 0.9) -> str:
        """生成回應"""
        if not self.is_ready:
            self.load_model()
        
        try:
            # 準備輸入
            if system_prompt:
                # 檢查分詞器是否有特殊的系統提示詞格式
                if hasattr(self.tokenizer, "apply_chat_template"):
                    messages = [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": prompt}
                    ]
                    input_text = self.tokenizer.apply_chat_template(messages, tokenize=False)
                else:
                    # 使用簡單的模板
                    input_text = f"<|system|>\n{system_prompt}\n<|user|>\n{prompt}\n<|assistant|>"
            else:
                input_text = prompt
            
            # 分詞
            inputs = self.tokenizer(input_text, return_tensors="pt")
            input_ids = inputs.input_ids.to(self.model.device)
            
            # 生成參數
            gen_kwargs = {
                "input_ids": input_ids,
                "max_new_tokens": max_new_tokens,
                "temperature": temperature,
                "top_p": top_p,
                "repetition_penalty": config.LOCAL_MODEL_REPETITION_PENALTY,
                "do_sample": temperature > 0,
                "pad_token_id": self.tokenizer.eos_token_id
            }
            
            # 生成回應
            with torch.no_grad():
                output = self.model.generate(**gen_kwargs)
            
            # 解碼回應
            response = self.tokenizer.decode(output[0][input_ids.shape[1]:], skip_special_tokens=True)
            
            return response
        except Exception as e:
            logger.error(f"生成回應時出錯: {e}")
            raise
    
    def generate_stream(self, prompt: str, system_prompt: str = None, max_new_tokens: int = 512,
                        temperature: float = 0.7, top_p: float = 0.9) -> Generator[str, None, None]:
        """流式生成回應"""
        if not self.is_ready:
            self.load_model()
        
        try:
            # 準備輸入
            if system_prompt:
                # 檢查分詞器是否有特殊的系統提示詞格式
                if hasattr(self.tokenizer, "apply_chat_template"):
                    messages = [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": prompt}
                    ]
                    input_text = self.tokenizer.apply_chat_template(messages, tokenize=False)
                else:
                    # 使用簡單的模板
                    input_text = f"<|system|>\n{system_prompt}\n<|user|>\n{prompt}\n<|assistant|>"
            else:
                input_text = prompt
            
            # 分詞
            inputs = self.tokenizer(input_text, return_tensors="pt")
            input_ids = inputs.input_ids.to(self.model.device)
            
            # 生成參數
            gen_kwargs = {
                "input_ids": input_ids,
                "max_new_tokens": max_new_tokens,
                "temperature": temperature,
                "top_p": top_p,
                "repetition_penalty": config.LOCAL_MODEL_REPETITION_PENALTY,
                "do_sample": temperature > 0,
                "pad_token_id": self.tokenizer.eos_token_id,
                "streamer": None  # 我們不使用內建的 streamer
            }
            
            # 流式生成
            generated_text = ""
            
            with torch.no_grad():
                # 初始輸入
                current_ids = input_ids.clone()
                past_key_values = None
                
                for _ in range(max_new_tokens):
                    # 使用模型進行前向傳播
                    with torch.no_grad():
                        outputs = self.model(
                            input_ids=current_ids[:, -1:] if past_key_values is not None else current_ids,
                            past_key_values=past_key_values,
                            use_cache=True
                        )
                    
                    # 獲取下一個 token 的 logits
                    next_token_logits = outputs.logits[:, -1, :]
                    
                    # 應用溫度和 top_p 採樣
                    if temperature > 0:
                        next_token_logits = next_token_logits / temperature
                        
                        # 應用 top_p 採樣
                        if top_p < 1.0:
                            sorted_logits, sorted_indices = torch.sort(next_token_logits, descending=True)
                            cumulative_probs = torch.cumsum(torch.softmax(sorted_logits, dim=-1), dim=-1)
                            
                            # 移除 top_p 之外的 tokens
                            sorted_indices_to_remove = cumulative_probs > top_p
                            sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
                            sorted_indices_to_remove[..., 0] = 0
                            
                            indices_to_remove = sorted_indices_to_remove.scatter(
                                1, sorted_indices, sorted_indices_to_remove
                            )
                            next_token_logits[indices_to_remove] = -float('Inf')
                        
                        # 採樣下一個 token
                        probs = torch.softmax(next_token_logits, dim=-1)
                        next_token = torch.multinomial(probs, num_samples=1)
                    else:
                        # 貪婪解碼
                        next_token = torch.argmax(next_token_logits, dim=-1, keepdim=True)
                    
                    # 將新 token 添加到序列
                    current_ids = torch.cat([current_ids, next_token], dim=-1)
                    
                    # 更新 past_key_values
                    past_key_values = outputs.past_key_values
                    
                    # 解碼新 token
                    new_token_text = self.tokenizer.decode(next_token[0], skip_special_tokens=True)
                    
                    # 如果生成了特殊 token 或 EOS，停止生成
                    if next_token[0].item() == self.tokenizer.eos_token_id:
                        break
                    
                    # 只有當新 token 不為空時才產生
                    if new_token_text:
                        generated_text += new_token_text
                        yield new_token_text
                    
                return generated_text
        except Exception as e:
            logger.error(f"流式生成回應時出錯: {e}")
            yield f"\n[生成錯誤: {str(e)}]"
            raise
    
    def _estimate_model_size(self) -> Optional[float]:
        """估計模型大小（GB）"""
        try:
            model_name = config.LOCAL_MODEL_NAME.lower()
            
            # 根據模型名稱估計大小
            if "7b" in model_name:
                return 14.0  # 7B 參數模型約 14GB (fp16)
            elif "13b" in model_name:
                return 26.0  # 13B 參數模型約 26GB (fp16)
            elif "70b" in model_name:
                return 140.0  # 70B 參數模型約 140GB (fp16)
            elif "phi-3-mini" in model_name:
                return 8.0  # Phi-3 Mini 約 8GB (fp16)
            elif "phi-3-medium" in model_name or "mistral-7b" in model_name:
                return 14.0  # 7B 參數模型約 14GB (fp16)
            elif "llama-3-8b" in model_name:
                return 16.0  # Llama 3 8B 約 16GB (fp16)
            
            # 默認估計
            return 8.0  # 默認假設為中小型模型
        except Exception:
            return None
    
    def _get_available_gpu_memory(self) -> Optional[float]:
        """獲取可用 GPU 記憶體（GB）"""
        try:
            if self.gpu_monitor:
                gpu_info = self.gpu_monitor.get_gpu_memory_info()
                if gpu_info and 0 in gpu_info:
                    return gpu_info[0]["free"]
            
            # 如果沒有 GPU 監控，嘗試直接獲取
            if torch.cuda.is_available():
                device = torch.cuda.current_device()
                free_memory, total_memory = torch.cuda.mem_get_info(device)
                return free_memory / (1024**3)  # 轉換為 GB
            
            return None
        except Exception:
            return None
    
    def get_gpu_memory_info(self) -> Dict[int, Dict[str, float]]:
        """獲取 GPU 記憶體信息"""
        if self.gpu_monitor:
            return self.gpu_monitor.get_gpu_memory_info()
        return {}