import os
import logging
import threading
import time
from typing import Optional, List, Dict, Any, Generator, Union, Callable
import config
import torch
from transformers import TextIteratorStreamer, AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import queue
from threading import Thread

logger = logging.getLogger("ModelLoader")

class ModelLoader:
    _instance = None
    
    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls._instance = ModelLoader()
        return cls._instance
    
    def __init__(self):
        self.model = None
        self.tokenizer = None
        self.is_ready = False
        self.is_loading = False
        self.lock = threading.Lock()
        self.gpu_monitor = None
        self.gguf_model = None
        self.gguf_is_ready = False
        self.gguf_is_loading = False
        
        # 嘗試導入 GPU 監控
        try:
            from utils.gpu_monitor import GPUMonitor
            self.gpu_monitor = GPUMonitor.get_instance()
        except ImportError:
            logger.warning("無法導入 GPUMonitor")
    
    def load_model(self):
        """載入模型"""
        with self.lock:
            if self.is_ready:
                logger.info("模型已經載入")
                return True
            
            if self.is_loading:
                logger.info("模型正在載入中")
                return False
            
            self.is_loading = True
        
        try:
            logger.info(f"開始載入模型: {config.LOCAL_MODEL_NAME}")
            start_time = time.time()
            
            # 記錄 GPU 記憶體狀態
            if torch.cuda.is_available():
                gpu_info = {}
                for i in range(torch.cuda.device_count()):
                    free_memory, total_memory = torch.cuda.mem_get_info(i)
                    free_memory = free_memory / (1024**3)  # 轉換為 GB
                    total_memory = total_memory / (1024**3)  # 轉換為 GB
                    reserved = torch.cuda.memory_reserved(i) / (1024**3)  # 轉換為 GB
                    allocated = torch.cuda.memory_allocated(i) / (1024**3)  # 轉換為 GB
                    gpu_info[i] = {
                        "total": round(total_memory, 2),
                        "reserved": round(reserved, 2),
                        "allocated": round(allocated, 2),
                        "free": round(free_memory, 2)
                    }
                logger.info(f"GPU 記憶體狀態: {gpu_info}")
            
            # 設置設備
            device = config.LOCAL_MODEL_DEVICE
            logger.info(f"使用設備: {device}")
            
            # 設置數據類型
            dtype_map = {
                "float16": torch.float16,
                "bfloat16": torch.bfloat16,
                "float32": torch.float32,
                "auto": "auto"
            }
            dtype = dtype_map.get(config.LOCAL_MODEL_DTYPE.lower(), "auto")
            logger.info(f"使用數據類型: {dtype}")
            
            # 設置量化配置
            quantization_config = None
            if config.LOCAL_MODEL_QUANTIZATION.lower() != "none":
                if config.LOCAL_MODEL_QUANTIZATION.lower() == "4bit":
                    quantization_config = BitsAndBytesConfig(
                        load_in_4bit=True,
                        bnb_4bit_compute_dtype=dtype if dtype != "auto" else torch.float16
                    )
                    logger.info("使用 4-bit 量化")
                elif config.LOCAL_MODEL_QUANTIZATION.lower() == "8bit":
                    quantization_config = BitsAndBytesConfig(
                        load_in_8bit=True
                    )
                    logger.info("使用 8-bit 量化")
                elif config.LOCAL_MODEL_QUANTIZATION.lower() == "auto":
                    # 自動選擇量化方式
                    model_size_gb = self._estimate_model_size()
                    available_memory = self._get_available_gpu_memory()
                    
                    if available_memory is not None and model_size_gb is not None:
                        logger.info(f"估計模型大小: {model_size_gb:.2f} GB, 可用 GPU 記憶體: {available_memory:.2f} GB")
                        
                        # 如果可用記憶體不足，使用量化
                        if model_size_gb > available_memory * 0.7:  # 留出 30% 緩衝
                            quantization_config = BitsAndBytesConfig(
                                load_in_4bit=True,
                                bnb_4bit_compute_dtype=dtype if dtype != "auto" else torch.float16
                            )
                            logger.info("自動選擇使用 4-bit 量化")
            
            # 設置 Hugging Face 令牌
            hf_token = config.HUGGINGFACE_TOKEN if hasattr(config, 'HUGGINGFACE_TOKEN') else None
            if hf_token:
                logger.info("使用 Hugging Face 令牌進行模型訪問")
            
            # 設置模型載入參數
            model_kwargs = {
                "pretrained_model_name_or_path": config.LOCAL_MODEL_NAME,
                "cache_dir": config.LOCAL_MODEL_CACHE_DIR if hasattr(config, 'LOCAL_MODEL_CACHE_DIR') else None,
                "torch_dtype": dtype if dtype != "auto" else "auto",
                "device_map": device if device != "cpu" else None,
                "quantization_config": quantization_config
            }
            
            # 如果有 Hugging Face 令牌，添加到參數中
            if hf_token:
                model_kwargs["token"] = hf_token
            
            # 如果啟用了 Flash Attention
            if hasattr(config, 'LOCAL_MODEL_USE_FLASH_ATTN') and config.LOCAL_MODEL_USE_FLASH_ATTN and device != "cpu":
                try:
                    model_kwargs["attn_implementation"] = "flash_attention_2"
                    logger.info("啟用 Flash Attention 2")
                except Exception as e:
                    logger.warning(f"無法啟用 Flash Attention: {e}")
            
            # 載入分詞器
            tokenizer_kwargs = {
                "pretrained_model_name_or_path": config.LOCAL_MODEL_NAME,
                "cache_dir": config.LOCAL_MODEL_CACHE_DIR if hasattr(config, 'LOCAL_MODEL_CACHE_DIR') else None
            }
            
            # 如果有 Hugging Face 令牌，添加到分詞器參數中
            if hf_token:
                tokenizer_kwargs["token"] = hf_token
            
            self.tokenizer = AutoTokenizer.from_pretrained(**tokenizer_kwargs)
            
            # 確保分詞器有 pad_token
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            # 載入模型
            self.model = AutoModelForCausalLM.from_pretrained(**model_kwargs)
            
            # 設置模型為評估模式
            self.model.eval()
            
            # 記錄載入時間
            load_time = time.time() - start_time
            logger.info(f"模型載入完成，耗時: {load_time:.2f} 秒")
            
            self.is_ready = True
            return True
        except Exception as e:
            logger.error(f"載入模型時發生錯誤：{e}")
            self.is_ready = False
            return False
        finally:
            self.is_loading = False
    
    def generate(self, prompt: str, generation_config: Dict[str, Any] = None) -> str:
        """生成回應"""
        if not self.is_ready:
            self.load_model()
        
        try:
            # 設置默認生成參數
            if generation_config is None:
                generation_config = {}
            
            max_new_tokens = generation_config.get("max_new_tokens", 512)
            temperature = generation_config.get("temperature", 0.7)
            top_p = generation_config.get("top_p", 0.9)
            repetition_penalty = generation_config.get("repetition_penalty", 1.1)
            do_sample = generation_config.get("do_sample", True)
            
            # 分詞
            inputs = self.tokenizer(prompt, return_tensors="pt")
            input_ids = inputs.input_ids.to(self.model.device)
            
            # 生成參數
            gen_kwargs = {
                "input_ids": input_ids,
                "max_new_tokens": max_new_tokens,
                "temperature": temperature,
                "top_p": top_p,
                "repetition_penalty": repetition_penalty,
                "do_sample": do_sample,
                "pad_token_id": self.tokenizer.eos_token_id
            }
            
            # 生成回應
            with torch.no_grad():
                output = self.model.generate(**gen_kwargs)
            
            # 解碼回應
            response = self.tokenizer.decode(output[0][input_ids.shape[1]:], skip_special_tokens=True)
            
            return response
        except Exception as e:
            logger.error(f"生成回應時出錯: {e}")
            raise
    
    def generate_stream(self, prompt: str, generation_config: Dict[str, Any] = None) -> Generator[str, None, None]:
        """流式生成回應"""
        if not self.is_ready:
            self.load_model()
        
        try:
            # 設置默認生成參數
            if generation_config is None:
                generation_config = {}
            
            max_new_tokens = generation_config.get("max_new_tokens", 512)
            temperature = generation_config.get("temperature", 0.7)
            top_p = generation_config.get("top_p", 0.9)
            repetition_penalty = generation_config.get("repetition_penalty", 1.1)
            do_sample = generation_config.get("do_sample", True)
            
            # 分詞
            inputs = self.tokenizer(prompt, return_tensors="pt")
            input_ids = inputs.input_ids.to(self.model.device)
            
            # 創建 TextIteratorStreamer
            streamer = TextIteratorStreamer(self.tokenizer, skip_prompt=True, skip_special_tokens=True)
            
            # 生成參數
            gen_kwargs = {
                "input_ids": input_ids,
                "max_new_tokens": max_new_tokens,
                "temperature": temperature,
                "top_p": top_p,
                "repetition_penalty": repetition_penalty,
                "do_sample": do_sample,
                "pad_token_id": self.tokenizer.eos_token_id,
                "streamer": streamer
            }
            
            # 在單獨的線程中運行生成
            generation_thread = Thread(target=self._generate_in_thread, args=(gen_kwargs,))
            generation_thread.start()
            
            # 從 streamer 獲取生成的 tokens
            for text in streamer:
                yield text
            
        except Exception as e:
            logger.error(f"流式生成回應時出錯: {e}")
            yield f"\n[生成錯誤: {str(e)}]"
    
    def _generate_in_thread(self, gen_kwargs: Dict[str, Any]):
        """在單獨的線程中運行生成"""
        try:
            with torch.no_grad():
                self.model.generate(**gen_kwargs)
        except Exception as e:
            logger.error(f"生成線程中出錯: {e}")
    
    def load_gguf_model(self):
        """載入 GGUF 模型"""
        with self.lock:
            if self.gguf_is_ready:
                logger.info("GGUF 模型已經載入")
                return True
            
            if self.gguf_is_loading:
                logger.info("GGUF 模型正在載入中")
                return False
            
            self.gguf_is_loading = True
        
        try:
            # 檢查 GGUF 模型路徑
            gguf_model_path = getattr(config, "LOCAL_GGUF_MODEL_PATH", None)
            if not gguf_model_path or not os.path.exists(gguf_model_path):
                logger.error(f"GGUF 模型路徑不存在: {gguf_model_path}")
                return False
            
            logger.info(f"開始載入 GGUF 模型: {gguf_model_path}")
            start_time = time.time()
            
            # 嘗試導入 llama-cpp-python
            try:
                from llama_cpp import Llama
            except ImportError:
                logger.error("無法導入 llama_cpp，請安裝 llama-cpp-python")
                return False
            
            # 設置 GGUF 模型參數
            n_gpu_layers = getattr(config, "LOCAL_GGUF_GPU_LAYERS", -1)
            n_ctx = getattr(config, "LOCAL_GGUF_CONTEXT_LENGTH", 4096)
            n_batch = getattr(config, "LOCAL_GGUF_BATCH_SIZE", 512)
            
            # 載入 GGUF 模型
            self.gguf_model = Llama(
                model_path=gguf_model_path,
                n_gpu_layers=n_gpu_layers,
                n_ctx=n_ctx,
                n_batch=n_batch,
                verbose=False
            )
            
            # 記錄載入時間
            load_time = time.time() - start_time
            logger.info(f"GGUF 模型載入完成，耗時: {load_time:.2f} 秒")
            
            self.gguf_is_ready = True
            return True
        except Exception as e:
            logger.error(f"載入 GGUF 模型時發生錯誤：{e}")
            return False
        finally:
            self.gguf_is_loading = False
    
    def unload_gguf_model(self):
        """卸載 GGUF 模型"""
        with self.lock:
            if self.gguf_is_ready and self.gguf_model is not None:
                self.gguf_model = None
                self.gguf_is_ready = False
                logger.info("GGUF 模型已卸載")
                return True
            return False
    
    def generate_with_gguf(self, prompt: str, generation_config: Dict[str, Any] = None) -> str:
        """使用 GGUF 模型生成回應"""
        if not self.gguf_is_ready:
            if not self.load_gguf_model():
                raise ValueError("無法載入 GGUF 模型")
        
        try:
            # 設置默認生成參數
            if generation_config is None:
                generation_config = {}
            
            max_tokens = generation_config.get("max_new_tokens", 512)
            temperature = generation_config.get("temperature", 0.7)
            top_p = generation_config.get("top_p", 0.9)
            repeat_penalty = generation_config.get("repetition_penalty", 1.1)
            
            # 生成回應
            response = self.gguf_model(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                repeat_penalty=repeat_penalty
            )
            
            # 獲取生成的文本
            generated_text = response["choices"][0]["text"]
            
            return generated_text
        except Exception as e:
            logger.error(f"GGUF 生成回應時出錯: {e}")
            raise
    
    def generate_with_gguf_stream(self, prompt: str, generation_config: Dict[str, Any] = None) -> Generator[str, None, None]:
        """使用 GGUF 模型流式生成回應"""
        if not self.gguf_is_ready:
            if not self.load_gguf_model():
                yield "[錯誤: 無法載入 GGUF 模型]"
                return
        
        try:
            # 設置默認生成參數
            if generation_config is None:
                generation_config = {}
            
            max_tokens = generation_config.get("max_new_tokens", 512)
            temperature = generation_config.get("temperature", 0.7)
            top_p = generation_config.get("top_p", 0.9)
            repeat_penalty = generation_config.get("repetition_penalty", 1.1)
            
            # 流式生成
            for chunk in self.gguf_model(
                prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                top_p=top_p,
                repeat_penalty=repeat_penalty,
                stream=True
            ):
                if chunk["choices"][0]["text"]:
                    yield chunk["choices"][0]["text"]
        
        except Exception as e:
            logger.error(f"GGUF 流式生成回應時出錯: {e}")
            yield f"\n[生成錯誤: {str(e)}]"
    
    def _estimate_model_size(self) -> Optional[float]:
        """估計模型大小（GB）"""
        try:
            model_name = config.LOCAL_MODEL_NAME.lower()
            
            # 根據模型名稱估計大小
            if "7b" in model_name:
                return 14.0  # 7B 參數模型約 14GB (fp16)
            elif "13b" in model_name:
                return 26.0  # 13B 參數模型約 26GB (fp16)
            elif "70b" in model_name:
                return 140.0  # 70B 參數模型約 140GB (fp16)
            elif "phi-3-mini" in model_name:
                return 8.0  # Phi-3 Mini 約 8GB (fp16)
            elif "phi-3-medium" in model_name or "mistral-7b" in model_name:
                return 14.0  # 7B 參數模型約 14GB (fp16)
            elif "llama-3-8b" in model_name:
                return 16.0  # Llama 3 8B 約 16GB (fp16)
            
            # 默認估計
            return 8.0  # 默認假設為中小型模型
        except Exception:
            return None
    
    def _get_available_gpu_memory(self) -> Optional[float]:
        """獲取可用 GPU 記憶體（GB）"""
        try:
            if self.gpu_monitor:
                gpu_info = self.gpu_monitor.get_gpu_memory_info()
                if gpu_info and 0 in gpu_info:
                    return gpu_info[0]["free"]
            
            # 如果沒有 GPU 監控，嘗試直接獲取
            if torch.cuda.is_available():
                device = torch.cuda.current_device()
                free_memory, total_memory = torch.cuda.mem_get_info(device)
                return free_memory / (1024**3)  # 轉換為 GB
            
            return None
        except Exception:
            return None
    
    def get_gpu_memory_info(self) -> Dict[int, Dict[str, float]]:
        """獲取 GPU 記憶體信息"""
        if self.gpu_monitor:
            return self.gpu_monitor.get_gpu_memory_info()
        return {}