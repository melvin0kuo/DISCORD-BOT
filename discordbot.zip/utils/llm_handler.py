import json
import requests
import aiohttp
import asyncio
import time
import concurrent.futures
from typing import List, Dict, Any, Optional, Generator, Union, Tuple
import config
import logging
from utils.model_loader import ModelLoader
import google.generativeai as genai
import os
import anthropic
import openai

# 設定日誌
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("LLMHandler")

class LLMHandler:
    def __init__(self, bot_name: str = "助手"):
        self.bot_name = bot_name
        self.system_prompt = config.LLM_SYSTEM_PROMPT.format(bot_name=bot_name)
        self.current_llm_type = config.DEFAULT_LLM_TYPE
        self.user_history = {}  # 用戶歷史記錄 {user_id: [messages]}
        
        # 初始化 API
        if config.OPENAI_API_KEY:
            self.openai_client = openai.OpenAI(api_key=config.OPENAI_API_KEY)
        else:
            self.openai_client = None
        
        if config.ANTHROPIC_API_KEY:
            self.anthropic_client = anthropic.Anthropic(api_key=config.ANTHROPIC_API_KEY)
        else:
            self.anthropic_client = None
        
        if config.GEMINI_API_KEY:
            genai.configure(api_key=config.GEMINI_API_KEY)
            self.gemini_model = genai.GenerativeModel(config.GEMINI_MODEL)
        else:
            self.gemini_model = None
    
    def switch_model(self, model_type: str) -> bool:
        """切換到指定的模型類型"""
        model_type = model_type.lower()
        valid_types = ["openai", "anthropic", "gemini", "local", "local_python", "local_gguf"]
        
        if model_type not in valid_types:
            logger.error(f"無效的模型類型: {model_type}")
            return False
        
        # 檢查模型是否可用
        if model_type == "openai" and not config.OPENAI_API_KEY:
            logger.error("OpenAI API 金鑰未設定")
            return False
        elif model_type == "anthropic" and not config.ANTHROPIC_API_KEY:
            logger.error("Anthropic API 金鑰未設定")
            return False
        elif model_type == "gemini" and not config.GEMINI_API_KEY:
            logger.error("Gemini API 金鑰未設定")
            return False
        
        self.current_llm_type = model_type
        logger.info(f"已切換到 {model_type} 模型")
        
        # 如果切換到 GGUF 模型，開始預加載
        if model_type == "local_gguf":
            asyncio.create_task(self._load_gguf_model())
        
        return True
    
    async def _load_gguf_model(self):
        """異步加載 GGUF 模型"""
        model_loader = ModelLoader.get_instance()
        
        # 在執行緒池中執行模型加載
        with concurrent.futures.ThreadPoolExecutor() as pool:
            result = await asyncio.get_event_loop().run_in_executor(
                pool, model_loader.load_gguf_model
            )
            
            return result
    
    def unload_gguf_model(self):
        """卸載 GGUF 模型"""
        model_loader = ModelLoader.get_instance()
        return model_loader.unload_gguf_model()
    
    def get_current_model_info(self) -> Dict[str, str]:
        """獲取當前模型信息"""
        model_info = {"type": self.current_llm_type}
        
        if self.current_llm_type == "openai":
            model_info["name"] = config.OPENAI_MODEL
        elif self.current_llm_type == "anthropic":
            model_info["name"] = config.ANTHROPIC_MODEL
        elif self.current_llm_type == "gemini":
            model_info["name"] = config.GEMINI_MODEL
        elif self.current_llm_type == "local":
            model_info["name"] = config.LOCAL_LLM_MODEL
        elif self.current_llm_type == "local_python":
            model_info["name"] = config.LOCAL_MODEL_NAME
            
            # 添加 GPU 使用信息
            model_loader = ModelLoader.get_instance()
            gpu_info = model_loader.get_gpu_memory_info()
            
            if gpu_info:
                for device_id, info in gpu_info.items():
                    model_info["gpu_usage"] = f"{info['allocated']:.2f}GB / {info['total']:.2f}GB"
                    if info.get("utilization") is not None:
                        model_info["gpu_util"] = f"{info['utilization']}%"
                    break  # 只顯示第一個 GPU
        
        elif self.current_llm_type == "local_gguf":
            model_info["name"] = os.path.basename(config.LOCAL_GGUF_MODEL_PATH)
            model_loader = ModelLoader.get_instance()
            
            if model_loader.gguf_is_ready:
                model_info["status"] = "已載入"
                
                # 嘗試獲取 GPU 使用信息
                try:
                    import pynvml
                    pynvml.nvmlInit()
                    device_count = pynvml.nvmlDeviceGetCount()
                    
                    if device_count > 0:
                        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
                        meminfo = pynvml.nvmlDeviceGetMemoryInfo(handle)
                        total = meminfo.total / (1024**3)
                        used = meminfo.used / (1024**3)
                        
                        model_info["gpu_usage"] = f"{used:.2f}GB / {total:.2f}GB"
                        
                        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
                        model_info["gpu_util"] = f"{util.gpu}%"
                except:
                    pass
            elif model_loader.gguf_is_loading:
                model_info["status"] = "正在載入..."
            else:
                model_info["status"] = "未載入"
        
        return model_info
    
    async def get_llm_response(self, user_id: str, message: str, stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """獲取 LLM 回應"""
        # 添加用戶消息到歷史記錄
        self.add_to_history(user_id, "user", message)
        
        # 獲取用戶的對話歷史
        history = self.get_history(user_id)
        
        # 根據當前模型類型獲取回應
        try:
            if self.current_llm_type == "openai":
                return await self._get_openai_response(history, stream)
            elif self.current_llm_type == "anthropic":
                return await self._get_anthropic_response(history, stream)
            elif self.current_llm_type == "gemini":
                return await self._get_gemini_response(history, stream)
            elif self.current_llm_type == "local":
                return await self._get_local_response(history, stream)
            elif self.current_llm_type == "local_python":
                return await self._get_local_python_response(history, stream)
            elif self.current_llm_type == "local_gguf":
                return await self._get_local_gguf_response(history, stream)
            else:
                raise ValueError(f"不支援的模型類型: {self.current_llm_type}")
        
        except Exception as e:
            logger.error(f"獲取 LLM 回應時出錯: {str(e)}")
            
            # 如果啟用了故障轉移，嘗試使用備用模型
            if config.ENABLE_FALLBACK and self.current_llm_type != config.FALLBACK_LLM_TYPE:
                logger.info(f"嘗試使用備用模型 {config.FALLBACK_LLM_TYPE}")
                original_type = self.current_llm_type
                self.current_llm_type = config.FALLBACK_LLM_TYPE
                
                try:
                    if stream:
                        async def fallback_stream():
                            yield f"[主要模型 ({original_type}) 發生錯誤: {str(e)}]\n"
                            yield f"[使用備用模型 ({config.FALLBACK_LLM_TYPE}) 回應...]\n\n"
                            
                            fallback_response = await self.get_llm_response(user_id, message, stream)
                            async for chunk in fallback_response:
                                yield chunk
                        
                        return fallback_stream()
                    else:
                        fallback_response = await self.get_llm_response(user_id, message, stream)
                        return f"[主要模型 ({original_type}) 發生錯誤: {str(e)}]\n[使用備用模型 ({config.FALLBACK_LLM_TYPE}) 回應...]\n\n{fallback_response}"
                
                except Exception as fallback_error:
                    logger.error(f"備用模型也失敗: {str(fallback_error)}")
                    self.current_llm_type = original_type  # 恢復原始模型類型
                    return f"錯誤: {str(e)}\n備用模型也失敗: {str(fallback_error)}"
            
            return f"錯誤: {str(e)}"
    
    async def _get_local_gguf_response(self, history: List[Dict[str, str]], stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """從本地 GGUF 模型獲取回應"""
        model_loader = ModelLoader.get_instance()
        
        # 檢查模型是否已載入
        if not model_loader.gguf_is_ready:
            # 如果模型尚未載入，嘗試載入
            if not model_loader.gguf_is_loading:
                logger.info("GGUF 模型尚未載入，開始載入...")
                await self._load_gguf_model()
            
            # 如果模型正在載入，等待一段時間
            timeout = 60  # 最多等待 60 秒
            start_time = time.time()
            
            while not model_loader.gguf_is_ready and time.time() - start_time < timeout:
                await asyncio.sleep(1)
            
            # 如果超時仍未載入完成，返回錯誤
            if not model_loader.gguf_is_ready:
                raise ValueError("GGUF 模型載入超時")
        
        # 準備提示
        prompt = self._format_gguf_prompt(history)
        
        # 生成參數
        generation_config = {
            "max_new_tokens": config.LOCAL_MODEL_MAX_NEW_TOKENS,
            "temperature": config.LOCAL_MODEL_TEMPERATURE,
            "top_p": config.LOCAL_MODEL_TOP_P,
            "repetition_penalty": config.LOCAL_MODEL_REPETITION_PENALTY
        }
        
        if stream:
            async def generate():
                collected_chunks = []
                
                # 在執行緒池中執行流式生成
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    stream_generator = model_loader.generate_with_gguf_stream(prompt, generation_config)
                    
                    # 使用執行緒池迭代生成器
                    def iterate_generator():
                        return list(stream_generator)
                    
                    chunks = await asyncio.get_event_loop().run_in_executor(pool, iterate_generator)
                    
                    for chunk in chunks:
                        collected_chunks.append(chunk)
                        yield chunk
                
                # 將完整回應添加到歷史記錄
                full_response = "".join(collected_chunks)
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", full_response)
            
            return generate()
        else:
            # 在執行緒池中執行生成
            with concurrent.futures.ThreadPoolExecutor() as pool:
                response = await asyncio.get_event_loop().run_in_executor(
                    pool, model_loader.generate_with_gguf, prompt, generation_config
                )
            
            # 添加到歷史記錄
            self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", response)
            return response
    
    def _format_gguf_prompt(self, history: List[Dict[str, str]]) -> str:
        """格式化 GGUF 模型的提示"""
        # 添加系統提示
        formatted_prompt = f"<|system|>\n{self.system_prompt}\n<|end|>\n"
        
        # 添加歷史對話
        for msg in history:
            role = msg["role"]
            content = msg["content"]
            
            if role == "user":
                formatted_prompt += f"<|user|>\n{content}\n<|end|>\n"
            elif role == "assistant":
                formatted_prompt += f"<|assistant|>\n{content}\n<|end|>\n"
        
        # 添加最後的助手標記，提示模型開始生成
        formatted_prompt += "<|assistant|>\n"
        
        return formatted_prompt
    
    def add_to_history(self, user_id: str, role: str, content: str) -> None:
        """添加消息到用戶歷史記錄"""
        if user_id not in self.user_history:
            self.user_history[user_id] = []
        
        self.user_history[user_id].append({
            "role": role,
            "content": content
        })
        
        # 限制歷史記錄長度
        if len(self.user_history[user_id]) > config.MAX_HISTORY_LENGTH * 2:  # 乘以 2 是因為每對對話有用戶和助手兩條消息
            self.user_history[user_id] = self.user_history[user_id][-config.MAX_HISTORY_LENGTH * 2:]
    
    def get_history(self, user_id: str) -> List[Dict[str, str]]:
        """獲取用戶的對話歷史"""
        if user_id not in self.user_history:
            return []
        
        # 添加用戶 ID 到每條消息中，以便在流式生成時使用
        history = self.user_history[user_id].copy()
        for msg in history:
            msg["user_id"] = user_id
        
        return history
    
    def clear_history(self, user_id: str) -> bool:
        """清除用戶的對話歷史"""
        if user_id in self.user_history:
            self.user_history[user_id] = []
            return True
        return False
    
    async def _get_openai_response(self, history: List[Dict[str, str]], stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """從 OpenAI 獲取回應"""
        if not self.openai_client:
            raise ValueError("OpenAI API 金鑰未設定")
        
        # 準備消息
        messages = [{"role": "system", "content": self.system_prompt}]
        for msg in history:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        if stream:
            async def generate():
                collected_chunks = []
                try:
                    stream_response = await asyncio.wait_for(
                        asyncio.to_thread(
                            lambda: self.openai_client.chat.completions.create(
                                model=config.OPENAI_MODEL,
                                messages=messages,
                                stream=True
                            )
                        ),
                        timeout=config.FALLBACK_TIMEOUT
                    )
                    
                    for chunk in stream_response:
                        if chunk.choices and chunk.choices[0].delta.content:
                            content = chunk.choices[0].delta.content
                            collected_chunks.append(content)
                            yield content
                except asyncio.TimeoutError:
                    logger.error("OpenAI API 請求超時")
                    yield "\n[生成超時，請嘗試縮短消息或使用其他模型]"
                except Exception as e:
                    logger.error(f"OpenAI 流式生成時出錯: {e}")
                    yield f"\n[生成錯誤: {str(e)}]"
                
                # 將完整回應添加到歷史記錄
                full_response = "".join(collected_chunks)
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", full_response)
            
            return generate()
        else:
            try:
                response = await asyncio.wait_for(
                    asyncio.to_thread(
                        lambda: self.openai_client.chat.completions.create(
                            model=config.OPENAI_MODEL,
                            messages=messages
                        )
                    ),
                    timeout=config.FALLBACK_TIMEOUT
                )
                
                content = response.choices[0].message.content
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", content)
                return content
            except asyncio.TimeoutError:
                raise ValueError("OpenAI API 請求超時")
            except Exception as e:
                raise ValueError(f"OpenAI API 請求失敗: {str(e)}")
    
    async def _get_anthropic_response(self, history: List[Dict[str, str]], stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """從 Anthropic 獲取回應"""
        if not self.anthropic_client:
            raise ValueError("Anthropic API 金鑰未設定")
        
        # 準備消息
        messages = [{"role": "system", "content": self.system_prompt}]
        for msg in history:
            role = "user" if msg["role"] == "user" else "assistant"
            messages.append({
                "role": role,
                "content": msg["content"]
            })
        
        if stream:
            async def generate():
                collected_chunks = []
                try:
                    stream_response = await asyncio.wait_for(
                        asyncio.to_thread(
                            lambda: self.anthropic_client.messages.create(
                                model=config.ANTHROPIC_MODEL,
                                messages=messages,
                                max_tokens=1024,
                                stream=True
                            )
                        ),
                        timeout=config.FALLBACK_TIMEOUT
                    )
                    
                    for chunk in stream_response:
                        if hasattr(chunk, 'delta') and hasattr(chunk.delta, 'text'):
                            content = chunk.delta.text
                            if content:
                                collected_chunks.append(content)
                                yield content
                except asyncio.TimeoutError:
                    logger.error("Anthropic API 請求超時")
                    yield "\n[生成超時，請嘗試縮短消息或使用其他模型]"
                except Exception as e:
                    logger.error(f"Anthropic 流式生成時出錯: {e}")
                    yield f"\n[生成錯誤: {str(e)}]"
                
                # 將完整回應添加到歷史記錄
                full_response = "".join(collected_chunks)
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", full_response)
            
            return generate()
        else:
            try:
                response = await asyncio.wait_for(
                    asyncio.to_thread(
                        lambda: self.anthropic_client.messages.create(
                            model=config.ANTHROPIC_MODEL,
                            messages=messages,
                            max_tokens=1024
                        )
                    ),
                    timeout=config.FALLBACK_TIMEOUT
                )
                
                content = response.content[0].text
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", content)
                return content
            except asyncio.TimeoutError:
                raise ValueError("Anthropic API 請求超時")
            except Exception as e:
                raise ValueError(f"Anthropic API 請求失敗: {str(e)}")
    
    async def _get_gemini_response(self, history: List[Dict[str, str]], stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """從 Gemini 獲取回應"""
        if not self.gemini_model:
            raise ValueError("Gemini API 金鑰未設定")
        
        # 準備消息
        chat = self.gemini_model.start_chat(history=[])
        
        # 添加系統提示作為第一條消息
        messages = [{"role": "system", "parts": [self.system_prompt]}]
        
        # 添加歷史消息
        for msg in history:
            role = "user" if msg["role"] == "user" else "model"
            messages.append({
                "role": role,
                "parts": [msg["content"]]
            })
        
        # 設定聊天歷史
        chat._history = messages
        
        if stream:
            async def generate():
                collected_chunks = []
                try:
                    # 獲取最後一條用戶消息
                    last_user_msg = history[-1]["content"] if history and history[-1]["role"] == "user" else ""
                    
                    # 使用執行緒池執行生成
                    with concurrent.futures.ThreadPoolExecutor() as pool:
                        response_future = asyncio.get_event_loop().run_in_executor(
                            pool,
                            lambda: chat.send_message(
                                last_user_msg,
                                stream=True,
                                generation_config=genai.types.GenerationConfig(
                                    temperature=config.LOCAL_MODEL_TEMPERATURE,
                                    top_p=config.LOCAL_MODEL_TOP_P,
                                    top_k=40,
                                    max_output_tokens=config.LOCAL_MODEL_MAX_NEW_TOKENS
                                )
                            )
                        )
                        
                        stream_response = await asyncio.wait_for(
                            response_future,
                            timeout=config.FALLBACK_TIMEOUT
                        )
                        
                        for chunk in stream_response:
                            if chunk.text:
                                collected_chunks.append(chunk.text)
                                yield chunk.text
                except asyncio.TimeoutError:
                    logger.error("Gemini API 請求超時")
                    yield "\n[生成超時，請嘗試縮短消息或使用其他模型]"
                except Exception as e:
                    logger.error(f"Gemini 流式生成時出錯: {e}")
                    yield f"\n[生成錯誤: {str(e)}]"
                
                # 將完整回應添加到歷史記錄
                full_response = "".join(collected_chunks)
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", full_response)
            
            return generate()
        else:
            try:
                # 獲取最後一條用戶消息
                last_user_msg = history[-1]["content"] if history and history[-1]["role"] == "user" else ""
                
                # 使用執行緒池執行生成
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    response_future = asyncio.get_event_loop().run_in_executor(
                        pool,
                        lambda: chat.send_message(
                            last_user_msg,
                            generation_config=genai.types.GenerationConfig(
                                temperature=config.LOCAL_MODEL_TEMPERATURE,
                                top_p=config.LOCAL_MODEL_TOP_P,
                                top_k=40,
                                max_output_tokens=config.LOCAL_MODEL_MAX_NEW_TOKENS
                            )
                        )
                    )
                    
                    response = await asyncio.wait_for(
                        response_future,
                        timeout=config.FALLBACK_TIMEOUT
                    )
                
                content = response.text
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", content)
                return content
            except asyncio.TimeoutError:
                raise ValueError("Gemini API 請求超時")
            except Exception as e:
                raise ValueError(f"Gemini API 請求失敗: {str(e)}")
    
    async def _get_local_response(self, history: List[Dict[str, str]], stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """從本地 API 服務器獲取回應"""
        # 準備消息
        messages = [{"role": "system", "content": self.system_prompt}]
        for msg in history:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # 準備 API 請求
        url = f"{config.LOCAL_LLM_URL}/chat/completions"
        headers = {"Content-Type": "application/json"}
        data = {
            "model": config.LOCAL_LLM_MODEL,
            "messages": messages,
            "temperature": config.LOCAL_MODEL_TEMPERATURE,
            "top_p": config.LOCAL_MODEL_TOP_P,
            "max_tokens": config.LOCAL_MODEL_MAX_NEW_TOKENS,
            "stream": stream
        }
        
        if stream:
            async def generate():
                collected_chunks = []
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.post(url, headers=headers, json=data, timeout=60) as response:
                            if response.status != 200:
                                error_text = await response.text()
                                raise ValueError(f"API 請求失敗 (狀態碼: {response.status}): {error_text}")
                            
                            # 處理流式回應
                            async for line in response.content:
                                line = line.decode('utf-8').strip()
                                if not line or line == "data: [DONE]":
                                    continue
                                
                                if line.startswith("data: "):
                                    try:
                                        json_data = json.loads(line[6:])
                                        if "choices" in json_data and json_data["choices"] and "delta" in json_data["choices"][0]:
                                            delta = json_data["choices"][0]["delta"]
                                            if "content" in delta and delta["content"]:
                                                content = delta["content"]
                                                collected_chunks.append(content)
                                                yield content
                                    except json.JSONDecodeError:
                                        logger.warning(f"無法解析 JSON: {line}")
                except asyncio.TimeoutError:
                    logger.error("本地 API 請求超時")
                    yield "\n[生成超時，請檢查本地服務器狀態]"
                except Exception as e:
                    logger.error(f"本地 API 流式生成時出錯: {e}")
                    yield f"\n[生成錯誤: {str(e)}]"
                
                # 將完整回應添加到歷史記錄
                full_response = "".join(collected_chunks)
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", full_response)
            
            return generate()
        else:
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(url, headers=headers, json=data, timeout=60) as response:
                        if response.status != 200:
                            error_text = await response.text()
                            raise ValueError(f"API 請求失敗 (狀態碼: {response.status}): {error_text}")
                        
                        response_data = await response.json()
                        content = response_data["choices"][0]["message"]["content"]
                        self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", content)
                        return content
            except asyncio.TimeoutError:
                raise ValueError("本地 API 請求超時")
            except Exception as e:
                raise ValueError(f"本地 API 請求失敗: {str(e)}")
    async def _get_local_python_response(self, history: List[Dict[str, str]], stream: bool = False) -> Union[str, Generator[str, None, None]]:
        """從本地 Python 模型獲取回應"""
        model_loader = ModelLoader.get_instance()
        
        # 檢查模型是否已載入
        if not model_loader.is_ready:
            # 如果模型尚未載入，嘗試載入
            if not model_loader.is_loading:
                logger.info("本地 Python 模型尚未載入，開始載入...")
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    await asyncio.get_event_loop().run_in_executor(
                        pool, model_loader.load_model
                    )
            
            # 如果模型正在載入，等待一段時間
            timeout = 120  # 最多等待 120 秒
            start_time = time.time()
            
            while not model_loader.is_ready and time.time() - start_time < timeout:
                await asyncio.sleep(1)
            
            # 如果超時仍未載入完成，返回錯誤
            if not model_loader.is_ready:
                raise ValueError("本地 Python 模型載入超時")
        
        # 準備消息
        messages = [{"role": "system", "content": self.system_prompt}]
        for msg in history:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # 生成參數
        generation_config = {
            "max_new_tokens": config.LOCAL_MODEL_MAX_NEW_TOKENS,
            "temperature": config.LOCAL_MODEL_TEMPERATURE,
            "top_p": config.LOCAL_MODEL_TOP_P,
            "repetition_penalty": config.LOCAL_MODEL_REPETITION_PENALTY,
            "do_sample": True
        }
        
        # 格式化提示
        prompt = self._format_prompt(messages)
        
        if stream:
            async def generate():
                collected_chunks = []
                
                # 在執行緒池中執行流式生成
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    stream_generator = model_loader.generate_stream(prompt, generation_config)
                    
                    # 使用執行緒池迭代生成器
                    async for chunk in self._async_generator_from_sync(stream_generator):
                        collected_chunks.append(chunk)
                        yield chunk
                
                # 將完整回應添加到歷史記錄
                full_response = "".join(collected_chunks)
                self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", full_response)
            
            return generate()
        else:
            # 在執行緒池中執行生成
            with concurrent.futures.ThreadPoolExecutor() as pool:
                response = await asyncio.get_event_loop().run_in_executor(
                    pool, model_loader.generate, prompt, generation_config
                )
            
            # 添加到歷史記錄
            self.add_to_history(history[-1].get("user_id", "unknown"), "assistant", response)
            return response

    async def _async_generator_from_sync(self, sync_gen):
        """將同步生成器轉換為異步生成器"""
        for item in sync_gen:
            yield item
            await asyncio.sleep(0)  # 讓出控制權給事件循環

    def _format_prompt(self, messages: List[Dict[str, str]]) -> str:
        """格式化提示"""
        formatted_prompt = ""
        
        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            
            if role == "system":
                formatted_prompt = f"{content}\n\n"
            elif role == "user":
                formatted_prompt += f"用戶: {content}\n"
            elif role == "assistant":
                formatted_prompt += f"助手: {content}\n"
        
        # 添加最後的助手標記，提示模型開始生成
        formatted_prompt += "助手: "
        
        return formatted_prompt